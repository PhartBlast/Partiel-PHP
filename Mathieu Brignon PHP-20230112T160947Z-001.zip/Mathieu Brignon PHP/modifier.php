<?php
$conn = mysqli_connect('localhost', 'root', 'root', 'partiel_mathieubrignon'); // connexion à la base de donnée 

if (!$conn) {
    die("Connexion erronée : " . mysqli_connect_error());
}

$sql = "UPDATE utilisateurs SET age = 18 WHERE nom = 'Guillaume'"; // Impatient de savoir ou se trouve mon erreur, j'ai pourtant essayer une dizaine de façon !

if (mysqli_query($conn, $sql)) {
    echo "Update réalisé avec succès";
} else {
    echo "Erreur lors de l'update : " . mysqli_error($conn);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="form">
        <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
        <h2>Modifier l'employé : <?= $row['nom'] ?> </h2>
        <p class="erreur_message">
        </p>
        <form action="" method="POST">
            <label>Nom</label>
            <input type="text" name="nom" value="">
            <label>Prénom</label>
            <input type="text" name="prenom" value="">
            <label>âge</label>
            <input type="number" name="age" value="">
            <input type="submit" value="Modifier" name="button">
        </form>
    </div>
</body>

</html>
