<?php
header( 'content-type: text/html; charset=utf-8' ); // Permettre à la base de donnée d'afficher les accennts
include 'db.php';

error_reporting(0);
session_start();

if (isset($_POST['supprimer'])){     // Impatient de savoir ou se trouve mon erreur, j'ai pourtant essayer une dizaine de façon ! j'ai essayé de reprendre la formule du ajouter.php pour la transformer en remove
// je pensais que c'était malin de contourner le supprimer déjà existant en créant un nouveau bouton : pas + de réussite :)
$ID=$_POST['ID'];
  
$sql = "DELETE FROM users WHERE ID = $ID";

$result=mysqli_query($conn, $sql);

if($result){
        echo "utilisateur ajouté !";
    }else{
        echo "erreur : " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="form">
        <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
        <h2>Supprimer un utilisateur</h2>
        <p class="erreur_message">
        </p>
        <form action="" method="POST">
            <label>id</label>
            <input type="text" name="nom">
            <input type="submit" value="supprimer" name="supprimer">
        </form>
    </div>
    <script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
</body>

</html>





